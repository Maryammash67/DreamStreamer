import boto3
from botocore.exceptions import ClientError
import json

# Initialize AWS services clients
dynamodb = boto3.resource('dynamodb')
s3_client = boto3.client('s3')

# Name of the DynamoDB table and S3 bucket
table_name = 'Albums'
bucket_name = 'album-art1'

def lambda_handler(event, context):
    try:
        # Parse the request body
        if isinstance(event.get('body'), str):
            event = json.loads(event['body'])

        # Extract album_id from the request
        album_id = event.get('album_id')

        # Ensure album_id is provided
        if not album_id:
            return {
                'statusCode': 400,
                'body': json.dumps({
                    'message': 'Album ID is required'
                })
            }

        # Get the table resource
        table = dynamodb.Table(table_name)

        # Retrieve the item to delete the corresponding S3 image as well
        try:
            response = table.get_item(Key={'album_id': album_id})
        except ClientError as e:
            return {
                'statusCode': 500,
                'body': json.dumps({
                    'message': 'Error retrieving album from DynamoDB',
                    'error': str(e)
                })
            }

        # Check if the item exists
        if 'Item' not in response:
            return {
                'statusCode': 404,
                'body': json.dumps({
                    'message': 'Album not found'
                })
            }

        album_art_url = response['Item'].get('AlbumArtURL')

        # Delete the item from DynamoDB
        try:
            table.delete_item(Key={'album_id': album_id})
        except ClientError as e:
            return {
                'statusCode': 500,
                'body': json.dumps({
                    'message': 'Error deleting album from DynamoDB',
                    'error': str(e)
                })
            }

        # If the album had an associated album art, delete it from S3
        if album_art_url:
            s3_key = f"albumArt/{album_id}.jpg"
            try:
                s3_client.delete_object(Bucket=bucket_name, Key=s3_key)
            except ClientError as e:
                return {
                    'statusCode': 500,
                    'body': json.dumps({
                        'message': 'Error deleting album art from S3',
                        'error': str(e)
                    })
                }

        # Return success response
        return {
            'statusCode': 200,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'DELETE, GET, POST, OPTIONS',
                'Access-Control-Allow-Headers': 'Content-Type'
            },
            'body': json.dumps({
                'message': 'Album deleted successfully'
            })
        }

    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({
                'message': 'Unexpected error occurred',
                'error': str(e)
            })
        }
