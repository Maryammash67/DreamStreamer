import pymysql
import json

def lambda_handler(event, context):
    # Database connection parameters
    db_endpoint = 'dreamstreamer.chq0iuuwcvg3.us-east-1.rds.amazonaws.com'
    db_username = 'admin'
    db_password = 'dreamstreamer'
    db_name = 'dreamstreamer1'

    # Parse the body if it comes from API Gateway
    if 'body' in event:
        try:
            # Body could be a JSON string, so we need to parse it
            body = json.loads(event['body']) if isinstance(event['body'], str) else event['body']
        except json.JSONDecodeError:
            return {
                'statusCode': 400,
                'headers': {
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': '*',
                    'Access-Control-Allow-Methods': 'POST'
                },
                'body': json.dumps({'message': 'Invalid JSON format'})
            }
    else:
        # If testing directly in Lambda, use the event as the body
        body = event

    # Extract album_id and user_id from the parsed body
    album_id = body.get('album_id')
    user_id = body.get('user_id')

    # Check if album_id and user_id are present
    if album_id is None or user_id is None:
        return {
            'statusCode': 400,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': '*',
                'Access-Control-Allow-Methods': 'POST'
            },
            'body': json.dumps({'message': 'album_id or user_id is missing from the input'})
        }

    # Connect to the database
    connection = pymysql.connect(
        host=db_endpoint,
        user=db_username,
        password=db_password,
        database=db_name
    )

    try:
        with connection.cursor() as cursor:
            # Check if the purchase already exists
            check_query = '''
                SELECT COUNT(*) FROM albumpurchases 
                WHERE album_id = %s AND user_id = %s;
            '''
            cursor.execute(check_query, (album_id, user_id))
            exists = cursor.fetchone()[0] > 0

            if exists:
                return {
                    'statusCode': 409,
                    'headers': {
                        'Access-Control-Allow-Origin': '*',
                        'Access-Control-Allow-Headers': '*',
                        'Access-Control-Allow-Methods': 'POST'
                    },
                    'body': json.dumps({'message': 'Purchase already exists for this album and user.'})
                }

            # Insert data into the albumpurchases table
            insert_query = '''
                INSERT INTO albumpurchases (album_id, user_id)
                VALUES (%s, %s);
            '''
            cursor.execute(insert_query, (album_id, user_id))
            connection.commit()
            return {
                'statusCode': 200,
                'headers': {
                    'Access-Control-Allow-Origin': '*',  # Allow CORS from any origin
                    'Access-Control-Allow-Headers': '*',
                    'Access-Control-Allow-Methods': 'POST'
                },
                'body': json.dumps({'message': 'Data inserted successfully.'})
            }
    except Exception as e:
        return {
            'statusCode': 500,
            'headers': {
                'Access-Control-Allow-Origin': '*',  # Allow CORS from any origin
                'Access-Control-Allow-Headers': '*',
                'Access-Control-Allow-Methods': 'POST'
            },
            'body': json.dumps({'message': f'Error inserting data: {str(e)}'})
        }
    finally:
        connection.close()
