import json
import boto3
from botocore.exceptions import ClientError

# Initialize AWS services clients
dynamodb = boto3.resource('dynamodb')
s3_client = boto3.client('s3')

# Name of the DynamoDB table and S3 bucket
table_name = 'Songs'
bucket_name = 'dreamstreamer-song1'

def lambda_handler(event, context):
    try:
        # Parse the request body
        if isinstance(event.get('body'), str):
            event = json.loads(event['body'])

        # Extract song_id from the request
        song_id = event.get('song_id')

        # Ensure song_id is provided
        if not song_id:
            return {
                'statusCode': 400,
                'body': json.dumps({
                    'message': 'Song ID is required'
                })
            }

        # Get the table resource
        table = dynamodb.Table(table_name)

        # Retrieve the item to delete the corresponding S3 file as well
        try:
            response = table.get_item(Key={'song_id': song_id})
        except ClientError as e:
            return {
                'statusCode': 500,
                'body': json.dumps({
                    'message': 'Error retrieving song from DynamoDB',
                    'error': str(e)
                })
            }

        # Check if the item exists
        if 'Item' not in response:
            return {
                'statusCode': 404,
                'body': json.dumps({
                    'message': 'Song not found'
                })
            }

        song_url = response['Item'].get('song_url')

        # Delete the item from DynamoDB
        try:
            table.delete_item(Key={'song_id': song_id})
        except ClientError as e:
            return {
                'statusCode': 500,
                'body': json.dumps({
                    'message': 'Error deleting song from DynamoDB',
                    'error': str(e)
                })
            }

        # If the song had an associated S3 URL, delete the file from S3
        if song_url:
            s3_key = song_url.split(f"https://{bucket_name}.s3.amazonaws.com/")[1]
            try:
                s3_client.delete_object(Bucket=bucket_name, Key=s3_key)
            except ClientError as e:
                return {
                    'statusCode': 500,
                    'body': json.dumps({
                        'message': 'Error deleting song file from S3',
                        'error': str(e)
                    })
                }

        # Return success response
        return {
            'statusCode': 200,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'DELETE, GET, POST, OPTIONS',
                'Access-Control-Allow-Headers': 'Content-Type'
            },
            'body': json.dumps({
                'message': 'Song deleted successfully'
            })
        }

    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({
                'message': 'Unexpected error occurred',
                'error': str(e)
            })
        }
