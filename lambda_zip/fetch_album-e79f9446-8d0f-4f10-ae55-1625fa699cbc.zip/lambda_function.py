import boto3
import json

# Initialize DynamoDB client
dynamodb = boto3.resource('dynamodb')
albums_table = dynamodb.Table('Albums')

def lambda_handler(event, context):
    try:
        # Scan the entire Albums table to fetch album_id and AlbumName
        response = albums_table.scan(
            ProjectionExpression="album_id, AlbumName"
        )
        
        albums = response['Items']

        return {
            'statusCode': 200,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': '*',
                'Access-Control-Allow-Methods': 'GET'
            },
            'body': json.dumps(albums)
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': '*',
                'Access-Control-Allow-Methods': 'GET'
            },
            'body': json.dumps({'message': f'Error fetching data: {str(e)}'})
        }
