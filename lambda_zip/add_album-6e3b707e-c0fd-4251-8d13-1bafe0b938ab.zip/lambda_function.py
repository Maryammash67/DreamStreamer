import json
import boto3
import uuid
from botocore.exceptions import ClientError
from decimal import Decimal
from base64 import b64decode

# Initialize DynamoDB and S3 resources
dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
s3_client = boto3.client('s3')
dynamodb_table = dynamodb.Table('Albums')  # Your table name
S3_BUCKET = 'album-art1'  # Your S3 bucket name

def lambda_handler(event, context):
    print('Request event:', event)
    response = None

    try:
        # Extract the body from the event if wrapped in another object
        body = event.get('body', event)
        
        # Parse the body
        album_data = json.loads(body)
        
        # Handle image upload if provided
        if 'imageBase64' in album_data:
            image_url = upload_image_to_s3(album_data['imageBase64'], album_data.get('AlbumName', 'default_image'))
            album_data['AlbumArtURL'] = image_url
        
        response = save_album(album_data)

    except Exception as e:
        print('Error:', e)
        response = build_response(400, 'Error processing request')

    return response

def upload_image_to_s3(image_base64, album_name):
    try:
        # Decode the base64 image
        image_data = b64decode(image_base64)
        image_key = f"{album_name}_{uuid.uuid4()}.png"

        # Upload the image to S3
        s3_client.put_object(Bucket=S3_BUCKET, Key=image_key, Body=image_data, ContentType='image/jpeg')

        # Generate the S3 URL
        image_url = f"https://{S3_BUCKET}.s3.amazonaws.com/{image_key}"
        return image_url

    except ClientError as e:
        print('S3 Error:', e)
        raise Exception('Image upload failed')

def save_album(album_data):
    try:
        # Use the provided id or generate a new one if not provided
        album_id = album_data.get('AlbumID', str(uuid.uuid4()))

        album_item = {
            'album_id': album_id,
            'AlbumName': album_data.get('AlbumName'),
            'AlbumYear': album_data.get('AlbumYear'),
            'Genre': album_data.get('Genre'),
            'Artists': album_data.get('Artists'),
            'TrackLabels': album_data.get('TrackLabels'),
            'BandComposition': album_data.get('BandComposition'),
            'AlbumArtURL': album_data.get('AlbumArtURL', '')  # Optional field
        }

        # Put the item in the DynamoDB table
        dynamodb_table.put_item(Item=album_item)

        body = {
            'Operation': 'SAVE',
            'Message': 'SUCCESS',
            'Item': album_item
        }
        return build_response(200, body)
    except ClientError as e:
        print('DynamoDB Error:', e)
        return build_response(400, e.response['Error']['Message'])

def build_response(status_code, body):
    return {
        'statusCode': status_code,
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Headers': 'Content-Type',
            'Access-Control-Allow-Methods': 'OPTIONS,POST'
        },
        'body': json.dumps(body, cls=DecimalEncoder)
    }

class DecimalEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, Decimal):
            if obj % 1 == 0:
                return int(obj)
            else:
                return float(obj)
        return super(DecimalEncoder, self).default(obj)
