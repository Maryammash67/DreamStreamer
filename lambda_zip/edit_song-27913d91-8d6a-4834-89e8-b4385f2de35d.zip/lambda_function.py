import json
import base64
import uuid  # To generate unique song_id if necessary
import boto3
from botocore.exceptions import ClientError

# Initialize AWS services clients
s3 = boto3.client('s3')
dynamodb = boto3.resource('dynamodb')

def lambda_handler(event, context):
    print("Received event:", json.dumps(event))  # Log the incoming event
    try:
        # Check if the event body is a string and needs decoding
        if 'body' in event:
            event_body = json.loads(event['body'])  # Parse the body if it's in a string format
        else:
            event_body = event  # Assume it's already parsed

        song_id = event_body['song_id']  # Use song_id to identify the song to be edited
        new_song_name = event_body.get('song_name')  # New song name, if provided
        new_song_data = event_body.get('song_data')  # New song data (base64), if provided
        new_album_id = event_body.get('album_id')  # New album ID, if the song is being moved to another album

        # Step 1: Retrieve the existing song record from the Songs table
        songs_table = dynamodb.Table('Songs')
        song_response = songs_table.get_item(Key={'song_id': song_id})

        if 'Item' not in song_response:
            return {
                'statusCode': 404,
                'body': json.dumps({
                    'message': f'Song with id {song_id} not found.'
                }),
                'headers': {
                    'Access-Control-Allow-Origin': '*',
                }
            }

        song_item = song_response['Item']
        existing_album_id = song_item['album_id']
        existing_s3_url = song_item['song_url']  # Existing song S3 URL
        existing_song_name = song_item['song_name']

        # Step 2: If a new album_id is provided, retrieve the new album details
        if new_album_id and new_album_id != existing_album_id:
            albums_table = dynamodb.Table('Albums')
            album_response = albums_table.get_item(Key={'album_id': new_album_id})

            if 'Item' not in album_response:
                return {
                    'statusCode': 404,
                    'body': json.dumps({
                        'message': f'Album with id {new_album_id} not found.'
                    }),
                    'headers': {
                        'Access-Control-Allow-Origin': '*',
                    }
                }

            # Retrieve new album details
            new_album_item = album_response['Item']
            new_album_name = new_album_item['AlbumName']
            new_artists = new_album_item['Artists']
            new_genre = new_album_item['Genre']

            # Move the song to the new album folder in S3
            s3_bucket = 'dreamstreamer-song1'  # Use your actual S3 bucket name
            sanitized_song_name = (new_song_name or existing_song_name).replace(" ", "_").lower()
            new_s3_key = f'songs/{new_album_id}/{sanitized_song_name}_{song_id}.mp3'

            # Copy the song to the new album folder in S3
            s3.copy_object(
                Bucket=s3_bucket,
                CopySource={'Bucket': s3_bucket, 'Key': existing_s3_url.split(f'https://{s3_bucket}.s3.amazonaws.com/')[1]},
                Key=new_s3_key,
                ContentType='audio/mpeg'
            )

            # Delete the original song from the old album's location in S3
            s3.delete_object(Bucket=s3_bucket, Key=existing_s3_url.split(f'https://{s3_bucket}.s3.amazonaws.com/')[1])

            # Update S3 URL for the new location
            updated_s3_url = f'https://{s3_bucket}.s3.amazonaws.com/{new_s3_key}'
        else:
            # If no new album, keep the existing album details and S3 URL
            new_album_id = existing_album_id
            new_album_name = song_item['AlbumName']
            new_artists = song_item['Artists']
            new_genre = song_item['Genre']
            updated_s3_url = existing_s3_url

        # Step 3: Handle the new song upload if song data is provided
        if new_song_data:
            new_song_data = fix_base64_padding(new_song_data)
            song_bytes = base64.b64decode(new_song_data)

            # Upload the new song data to the correct S3 location
            s3.put_object(
                Bucket=s3_bucket,
                Key=new_s3_key,  # Use the new or existing album path
                Body=song_bytes,
                ContentType='audio/mpeg'
            )

            # The S3 URL remains the same in this case
            updated_s3_url = f'https://{s3_bucket}.s3.amazonaws.com/{new_s3_key}'

        # Step 4: Update the song record in the Songs table with new album details (if changed)
        updated_song_name = new_song_name if new_song_name else existing_song_name

        songs_table.update_item(
            Key={'song_id': song_id},
            UpdateExpression="SET song_name = :song_name, song_url = :song_url, album_id = :album_id, AlbumName = :AlbumName, Artists = :Artists, Genre = :Genre",
            ExpressionAttributeValues={
                ':song_name': updated_song_name,
                ':song_url': updated_s3_url,
                ':album_id': new_album_id,
                ':AlbumName': new_album_name,
                ':Artists': new_artists,
                ':Genre': new_genre
            }
        )

        # Step 5: Return success response
        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': 'Song successfully updated!',
                'song_id': song_id,
                'new_song_name': updated_song_name,
                'song_url': updated_s3_url,
                'new_album_id': new_album_id,
                'new_album_name': new_album_name
            }),
            'headers': {
                'Access-Control-Allow-Origin': '*',
            }
        }

    except ClientError as e:
        print(f"Error: {e}")
        return {
            'statusCode': 500,
            'body': json.dumps({
                'message': 'Error updating song',
                'error': str(e)
            }),
            'headers': {
                'Access-Control-Allow-Origin': '*',
            }
        }

    except Exception as e:
        print(f"Unexpected error: {e}")
        return {
            'statusCode': 500,
            'body': json.dumps({
                'message': 'Unexpected error occurred',
                'error': str(e)
            }),
            'headers': {
                'Access-Control-Allow-Origin': '*',
            }
        }

# Function to fix base64 padding
def fix_base64_padding(base64_string):
    missing_padding = len(base64_string) % 4
    if missing_padding != 0:
        base64_string += '=' * (4 - missing_padding)
    return base64_string