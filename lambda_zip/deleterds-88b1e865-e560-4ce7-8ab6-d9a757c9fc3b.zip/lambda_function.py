import pymysql
import json

def lambda_handler(event, context):
    # Database connection parameters
    db_endpoint = 'dreamstreamer.chq0iuuwcvg3.us-east-1.rds.amazonaws.com'
    db_username = 'admin'
    db_password = 'dreamstreamer'
    db_name = 'dreamstreamer1'

    # Parse input data from the event body
    body = json.loads(event['body'])
    user_id = body.get('user_id')
    album_id = body.get('album_id')

    # Connect to the database
    connection = pymysql.connect(
        host=db_endpoint,
        user=db_username,
        password=db_password,
        database=db_name
    )

    try:
        with connection.cursor() as cursor:
            # SQL query to delete the record
            delete_query = '''
                DELETE FROM albumpurchases WHERE user_id = %s AND album_id = %s;
            '''
            cursor.execute(delete_query, (user_id, album_id))
            connection.commit()

            # Return success message
            return {
                'statusCode': 200,
                'headers': {
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': '*',
                    'Access-Control-Allow-Methods': 'DELETE'
                },
                'body': json.dumps({'message': 'Purchase deleted successfully'})
            }

    except Exception as e:
        return {
            'statusCode': 500,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': '*',
                'Access-Control-Allow-Methods': 'DELETE'
            },
            'body': json.dumps({'message': f'Error deleting purchase: {str(e)}'})
        }
    finally:
        connection.close()
