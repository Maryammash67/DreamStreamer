import json
import boto3

# Initialize AWS clients
dynamodb = boto3.resource('dynamodb')
sns = boto3.client('sns')

ALBUMS_TABLE = "Albums"  
SONGS_TABLE = "Songs"   
SNS_TOPIC_ARN = "arn:aws:sns:us-east-1:992382437833:sns"  

def lambda_handler(event, context):
    try:
        albums = fetch_albums()
        songs = fetch_songs()

        report_content = create_inventory_report(albums, songs)

        sns.publish(
            TopicArn=SNS_TOPIC_ARN,
            Message=report_content,
            Subject="Inventory Report"
        )

        return {
            'statusCode': 200,
            'body': json.dumps({'message': "Report sent successfully!"}),
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type',
                'Access-Control-Allow-Methods': 'OPTIONS,POST'
            }
        }

    except Exception as e:
        print("Error sending report:", e)
        return {
            'statusCode': 500,
            'body': json.dumps({'error': "Failed to send report"}),
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type',
                'Access-Control-Allow-Methods': 'OPTIONS,POST'
            }
        }

def fetch_albums():
    table = dynamodb.Table(ALBUMS_TABLE)
    response = table.scan()
    return response['Items']

def fetch_songs():
    table = dynamodb.Table(SONGS_TABLE)
    response = table.scan()
    return response['Items']

def create_inventory_report(albums, songs):
    report = "Inventory Report:\n\nAlbums:\n"
    for album in albums:
        album_name = album.get('AlbumName', 'Unknown')
        artists = album.get('Artists', 'Unknown')
        year = album.get('AlbumYear', 'Unknown')  # Adding Year to the report
        genre = album.get('Genre', 'Unknown')  # Adding Genre to the report
        report += f"- {album_name} by '{artists}', Year: {year}, Genre: {genre}\n"

    report += "\nSongs:\n"
    for song in songs:
        song_name = song.get('song_name', 'Unknown')
        album_name = song.get('AlbumName', 'Unknown')
        report += f"- {song_name} from '{album_name}'\n"

    return report