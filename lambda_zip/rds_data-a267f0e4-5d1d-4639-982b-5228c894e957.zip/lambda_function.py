import pymysql
import json

def lambda_handler(event, context):
    # Database connection parameters
    db_endpoint = 'dreamstreamer.chq0iuuwcvg3.us-east-1.rds.amazonaws.com'
    db_username = 'admin'
    db_password = 'dreamstreamer'
    db_name = 'dreamstreamer1'

    # Connect to the database
    connection = pymysql.connect(
        host=db_endpoint,
        user=db_username,
        password=db_password,
        database=db_name
    )

    try:
        with connection.cursor(pymysql.cursors.DictCursor) as cursor:
            # Query to fetch all records from albumpurchases
            select_query = 'SELECT * FROM albumpurchases;'
            cursor.execute(select_query)
            results = cursor.fetchall()

            # Return the fetched records as a JSON response
            return {
                'statusCode': 200,
                'headers': {
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': '*',
                    'Access-Control-Allow-Methods': 'GET'
                },
                'body': json.dumps(results)
            }
    except Exception as e:
        return {
            'statusCode': 500,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': '*',
                'Access-Control-Allow-Methods': 'GET'
            },
            'body': json.dumps({'message': f'Error fetching data: {str(e)}'})
        }
    finally:
        connection.close()
