import json
import base64
import uuid  # To generate unique song_id
import boto3
from botocore.exceptions import ClientError

# Initialize AWS services clients
s3 = boto3.client('s3')
dynamodb = boto3.resource('dynamodb')

def lambda_handler(event, context):
    print("Received event:", json.dumps(event))  # Log the incoming event
    try:
        # Check if the event body is a string and needs decoding
        if 'body' in event:
            event_body = json.loads(event['body'])  # Parse the body if it's in a string format
        else:
            event_body = event  # Assume it's already parsed
        
        album_id = event_body['album_id']  # Use album_id directly from the event
        songs = event_body['songs']

        if not (1 <= len(songs) <= 5):
            return {
                'statusCode': 400,
                'body': json.dumps({
                    'message': 'You must upload at least 1 song and at most 5 songs.'
                }),
                'headers': {
                    'Access-Control-Allow-Origin': '*',
                }
            }

        # Step 1: Retrieve AlbumName and Artists from the Albums table using album_id
        albums_table = dynamodb.Table('Albums')
        album_response = albums_table.get_item(
            Key={'album_id': album_id}
        )

        if 'Item' not in album_response:
            return {
                'statusCode': 404,
                'body': json.dumps({
                    'message': f'Album with id {album_id} not found.'
                }),
                'headers': {
                    'Access-Control-Allow-Origin': '*',
                }
            }

        album_item = album_response['Item']
        album_name = album_item['AlbumName']
        artists = album_item['Artists']
        genre = album_item['Genre']

        # Prepare to upload songs and insert them into the Songs table
        s3_bucket = 'dreamstreamer-song1'  # Use your actual S3 bucket name
        song_urls = []
        songs_table = dynamodb.Table('Songs')

        # Step 2: Iterate through each song, upload it to S3, and add an entry in the Songs table
        for song in songs:
            song_name = song['song_name']
            song_base64 = song['song_data']
            song_base64 = fix_base64_padding(song_base64)
            song_bytes = base64.b64decode(song_base64)

            # Generate unique song_id and S3 key, including song name
            song_id = str(uuid.uuid4())
            sanitized_song_name = song_name.replace(" ", "_").lower()  # Sanitize song name for S3 key
            s3_key = f'songs/{album_id}/{sanitized_song_name}_{song_id}.mp3'  # Save songs in the 'songs/' folder

            # Upload song to S3
            s3.put_object(
                Bucket=s3_bucket,
                Key=s3_key,
                Body=song_bytes,
                ContentType='audio/mpeg'
            )

            # Generate the S3 URL for the uploaded song
            s3_url = f'https://{s3_bucket}.s3.amazonaws.com/{s3_key}'
            song_urls.append(s3_url)

            # Insert the song record into the Songs table
            songs_table.put_item(
                Item={
                    'song_id': song_id,
                    'album_id': album_id,
                    'song_name': song_name,  # Store the song name in DynamoDB
                    'song_url': s3_url,
                    'AlbumName': album_name,  # Save the AlbumName
                    'Artists': artists,        # Save the Artists
                    'Genre': genre   
                }
            )

        # Step 3: Return success response
        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': 'Songs successfully uploaded!',
                'album_id': album_id,
                'song_urls': song_urls
            }),
            'headers': {
                'Access-Control-Allow-Origin': '*',
            }
        }

    except ClientError as e:
        print(f"Error: {e}")
        return {
            'statusCode': 500,
            'body': json.dumps({
                'message': 'Error uploading songs',
                'error': str(e)
            }),
            'headers': {
                'Access-Control-Allow-Origin': '*',
            }
        }

    except Exception as e:
        print(f"Unexpected error: {e}")
        return {
            'statusCode': 500,
            'body': json.dumps({
                'message': 'Unexpected error occurred',
                'error': str(e)
            }),
            'headers': {
                'Access-Control-Allow-Origin': '*',
            }
        }

# Function to fix base64 padding
def fix_base64_padding(base64_string):
    missing_padding = len(base64_string) % 4
    if missing_padding != 0:
        base64_string += '=' * (4 - missing_padding)
    return base64_string
