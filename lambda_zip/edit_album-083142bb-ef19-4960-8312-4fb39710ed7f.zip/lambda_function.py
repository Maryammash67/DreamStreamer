import base64
import json
import boto3
from botocore.exceptions import ClientError
from decimal import Decimal

# Initialize AWS services clients
dynamodb = boto3.resource('dynamodb')
s3_client = boto3.client('s3')

# Name of the DynamoDB table and S3 bucket
table_name = 'Albums'
bucket_name = 'album-art1'

# Custom JSON encoder to handle Decimal types
class DecimalEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, Decimal):
            return float(obj) if obj % 1 else int(obj)
        return super(DecimalEncoder, self).default(obj)

# Function to fix base64 padding
def fix_base64_padding(base64_string):
    # Add the correct padding if it's missing
    missing_padding = len(base64_string) % 4
    if missing_padding != 0:
        base64_string += '=' * (4 - missing_padding)
    return base64_string

def lambda_handler(event, context):
    try:
        # Parse the request body
        if isinstance(event.get('body'), str):
            event = json.loads(event['body'])

               # Extract data to update
        album_id = event['album_id']
        album_name = event.get('AlbumName')  # Using .get to handle optional fields
        genre = event.get('Genre')
        artist_name = event.get('Artists')
        album_year = event.get('AlbumYear')
        track_labels = event.get('TrackLabels')  # Assumed to be a list of strings
        band_composition = event.get('BandComposition')
        album_art_base64 = event.get('AlbumArtURL')  # Base64 encoded image data (optional)
        
          
        # If new album art is provided, fix padding and upload to S3
        album_art_url = None
        if album_art_base64:
            # Fix base64 string padding if necessary
            album_art_base64 = fix_base64_padding(album_art_base64)

            # Decode the base64 string to bytes
            try:
                album_art_bytes = base64.b64decode(album_art_base64)
            except Exception as e:
                return {
                    'statusCode': 400,
                    'body': json.dumps({
                        'message': 'Error decoding Base64 image data',
                        'error': str(e)
                    })
                }

            # Upload the decoded image bytes directly to S3
            s3_key = f"albumArt/{album_id}.jpg"  # Use AlbumID for the image filename
            try:
                s3_client.put_object(
                    Bucket=bucket_name,
                    Key=s3_key,
                    Body=album_art_bytes,
                    ContentType='image/png'
                )
                album_art_url = f"https://{bucket_name}.s3.amazonaws.com/{s3_key}"
            except ClientError as e:
                return {
                    'statusCode': 500,
                    'body': json.dumps({
                        'message': 'Error uploading image to S3',
                        'error': str(e)
                    })
                }

        # Prepare the update expression for DynamoDB
        update_expression = "set "
        expression_attribute_values = {}

        # Only include fields that are provided in the request
        if album_name:
            update_expression += "AlbumName=:n, "
            expression_attribute_values[':n'] = album_name
        if genre:
            update_expression += "Genre=:g, "
            expression_attribute_values[':g'] = genre
        if artist_name:
            update_expression += "Artists=:a, "
            expression_attribute_values[':a'] = artist_name
        if album_year:
            update_expression += "AlbumYear=:y, "
            expression_attribute_values[':y'] = album_year
        if track_labels:
            update_expression += "TrackLabels=:t, "
            expression_attribute_values[':t'] = track_labels
        if band_composition:
            update_expression += "BandComposition=:b, "
            expression_attribute_values[':b'] = band_composition
        if album_art_url:
            update_expression += "AlbumArtURL=:u, "
            expression_attribute_values[':u'] = album_art_url

        # Remove trailing comma and space from update expression
        if update_expression.endswith(", "):
            update_expression = update_expression[:-2]

        # Ensure there are fields to update
        if not expression_attribute_values:
            return {
                'statusCode': 400,
                'body': json.dumps({
                    'message': 'No attributes provided to update'
                })
            }

        # Get the table resource
        table = dynamodb.Table(table_name)

        # Update the album data in DynamoDB
        response = table.update_item(
            Key={'album_id': album_id},
            UpdateExpression=update_expression,
            ExpressionAttributeValues=expression_attribute_values,
            ReturnValues="UPDATED_NEW"
        )

        # Return success response, using DecimalEncoder to serialize Decimals
        return {
            'statusCode': 200,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'PUT, GET, POST, OPTIONS',
                'Access-Control-Allow-Headers': 'Content-Type'
            },
            'body': json.dumps({
                'message': 'Album updated successfully!',
                'updatedAttributes': response['Attributes']
            }, cls=DecimalEncoder)  # Using DecimalEncoder for Decimal conversion
        }

    except ClientError as e:
        return {
            'statusCode': 500,
            'body': json.dumps({
                'message': 'Error updating album',
                'error': str(e)
            })
        }

    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({
                'message': 'Unexpected error occurred',
                'error': str(e)
            })
        }