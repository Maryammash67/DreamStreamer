import json
import boto3
from decimal import Decimal
from botocore.exceptions import ClientError

# Initialize AWS services clients
dynamodb = boto3.resource('dynamodb')

# Name of the DynamoDB table
table_name = 'Songs'

# Custom JSON encoder to handle Decimal types
class DecimalEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, Decimal):
            # Convert Decimal to float or int
            return float(obj) if obj % 1 else int(obj)
        return super(DecimalEncoder, self).default(obj)

def lambda_handler(event, context):
    try:
        # Get the table resource
        table = dynamodb.Table(table_name)

        # Scan the table to get all album entries
        response = table.scan()
        songs = response.get('Items', [])

        # Return the list of albums with custom Decimal handling
        return {
            'statusCode': 200,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'POST, GET, OPTIONS',
                'Access-Control-Allow-Headers': 'Content-Type'
            },
            'body': json.dumps(songs, cls=DecimalEncoder)  # Use custom encoder here
        }

    except ClientError as e:
        print(f"Error: {e}")
        return {
            'statusCode': 500,
            'body': json.dumps({
                'message': 'Error fetching albums',
                'error': str(e)
            })
        }